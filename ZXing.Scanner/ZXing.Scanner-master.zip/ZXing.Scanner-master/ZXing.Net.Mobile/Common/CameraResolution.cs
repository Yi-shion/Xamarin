﻿using System;

namespace ZXing.Mobile
{
	public class CameraResolution
	{
		public int Width { get;set; }
		public int Height { get;set; }
	}
}

